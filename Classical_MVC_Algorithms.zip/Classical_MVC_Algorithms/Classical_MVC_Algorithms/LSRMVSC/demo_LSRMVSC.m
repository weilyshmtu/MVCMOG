clc;
clear
close all


datasets = ["3sources", "COIL20","MNIST-10k","NUS-WIDE"]
datapath = 'C:\Users\admin\OneDrive\科研\程序\DataSets\Multi-view datasets';
addpath(datapath)
addpath(genpath('.\LSRMVSC'))


% parameter setting
eta = [1e2, 1e3, 1e4];
gamma = [10,20,30,40,50];
k= [1,2,3,4,5];

rng('default')
for d_ind=1:length(datasets)
    % filename = "LSRMVSC_" + datasets(d_ind)+ ".txt";
    % fileID = fopen(filename, 'wt');

    load(datasets(d_ind));

    if ~exist("Y","var")
        Y = y;
    end
    n_clusters = max(unique(Y));
    if min(unique(Y))==0
        n_clusters = n_clusters+1;
    end
   

    % =====================  run =====================
    for k_ind=1:length(k)
        for eta_ind=1:length(eta)
            for gamma_ind = 1:length(gamma)
                curr_result = LSRMSC(X, Y, eta(eta_ind), gamma(gamma_ind), k(k_ind))
                acc1(k_ind,eta_ind,gamma_ind) = curr_result(1)
                nmi1(k_ind,eta_ind,gamma_ind) = curr_result(2)
                ari1(k_ind,eta_ind,gamma_ind) = curr_result(3);
                fscore1(k_ind,eta_ind,gamma_ind) = curr_result(4)
                purity1(k_ind,eta_ind,gamma_ind) = curr_result(5);
                precision1(k_ind,eta_ind,gamma_ind) = curr_result(6);
                recall1(k_ind,eta_ind,gamma_ind) = curr_result(7);
                % param = [eta(eta), gamma(gamma), k(k)];
                % for p_ind = 1:length(param) 
                %     fprintf(fileID, " param_" + num2str(p_ind)+": " + num2str(param(p_ind)));
                % end
                % fprintf(fileID, " acc: %4.2f, nmi: %4.2f, ari: %4.2f, Fscore: %4.2f\n", result(1)*100, result(2)*100, result(3)*100, result(4)*100);  
            end
        end
    end
    if ~exist("results","dir")
        mkdir("results")
    end
    cd("results")
    result_name = datasets(d_ind);
    save(result_name, "acc1" , "nmi1", "ari1", "fscore1", "purity1", ...
    "precision1", "recall1");
    cd ..
    clear acc1 nmi1 ari1 fscore1 purity1 precision1 recall1
end