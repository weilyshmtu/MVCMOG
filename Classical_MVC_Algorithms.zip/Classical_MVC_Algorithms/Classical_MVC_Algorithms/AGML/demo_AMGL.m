clear
clc
close all

datasets = ["3sources","COIL20","MNIST-10k","NUS-WIDE"];
datapath = 'C:\Users\admin\OneDrive\科研\程序\DataSets\Multi-view datasets';
addpath(datapath)
addpath(genpath('.\AMGL'))

k_set = 3:2:15;
rng('default')
for d_ind=1:length(datasets)
    % filename = "AMGL_" + datasets(d_ind)+ ".txt";
    % fileID = fopen(filename, 'wt');

    load(datasets(d_ind));

    normX = normalize(X);   % to let each data sample has unit l_2 norm
    for v_ind =1:length(X)  % let each column of Xi represent a data sample
        X{v_ind} = normX{v_ind}';
    end

    if ~exist("Y","var")
        Y = y;
    end
    n_clusters = max(unique(Y));
    if min(unique(Y)) == 0
        n_clusters = n_clusters + 1;
    end
    
    for k_ind = 1:length(k_set)
        curr_result = AMGL_Clustering(X,Y,k_set(k_ind),n_clusters);
        acc1(k_ind) = curr_result(1)
        nmi1(k_ind) = curr_result(2)
        ari1(k_ind) = curr_result(3);
        fscore1(k_ind) = curr_result(4)
        purity1(k_ind) = curr_result(5);
        precision1(k_ind) = curr_result(6);
        recall1(k_ind) = curr_result(7);

        % param1 = k_set(k_ind);
        % param = [param1];
        % for p_ind = 1:length(param) 
        %     fprintf(fileID, " param_" + num2str(p_ind)+": " + num2str(param(p_ind)));
        % end
        % fprintf(fileID, " acc: %4.2f, nmi: %4.2f, ari: %4.2f, Fscore: %4.2f\n", result(1)*100, result(2)*100, result(3)*100, result(4)*100);  
        % fclose(fileID)
    end
    if ~exist("results","dir")
        mkdir("results")
    end
    cd("results")
    result_name = datasets(d_ind);
    save(result_name, "acc1" , "nmi1", "ari1", "fscore1", "purity1", ...
    "precision1", "recall1");
    cd ..
    clear acc1 nmi1 ari1 fscore1 purity1 precision1 recall1

end


function normX = normalize(X)
    n = size(X{1},1) ;
    for i=1:length(X)
        tX = X{i};
        for j=1:n
            tX(j,:) = tX(j,:)/(norm(tX(j,:),2)+eps);
        end
        normX{i} = tX;
    end
end