clear
clc
close all

datasets = ["3sources", "COIL20","MNIST-10k","NUS-WIDE"]
datapath = 'C:\Users\admin\OneDrive\科研\程序\DataSets\Multi-view datasets';
addpath(datapath)
addpath(genpath('.\GMC'))

rtimes = 1; % run-times on each dataset, default: 1

k_set = [5,10,15,20];
lambda_set = [0.5,1,3,5];

rng('default')
for d_ind = 1:length(datasets)
    % filename = "GMC_" + datasets(d_ind) + ".txt";
    % fileID = fopen(filename, 'wt');

    load(datasets(d_ind));  
   
    % X = normalize(X); % GMC has its normalization
    normData = 1;
    for d_ind =1:length(X)   % let each column of Xi represent a data sample
        X{d_ind} = X{d_ind}';
    end

    if ~exist("Y","var")
        Y = y;
    end
    n_clusters = max(unique(Y));
    if min(unique(Y))==0
        n_clusters = n_clusters+1;
    end
    %% iteration ...
    for k_ind=1:length(k_set)
        for lambda_ind=1:length(lambda_set)
            [C, predY] = GMC(X, k_set(k_ind), lambda_set(lambda_ind), n_clusters,normData); % c: the # of clusters
            curr_result = Clustering8Measure(Y, predY');
            acc1(k_ind, lambda_ind) = curr_result(1)
            nmi1(k_ind, lambda_ind) = curr_result(2)
            ari1(k_ind, lambda_ind) = curr_result(3);
            fscore1(k_ind, lambda_ind) = curr_result(4)
            purity1(k_ind, lambda_ind) = curr_result(5);
            precision1(k_ind, lambda_ind) = curr_result(6);
            recall1(k_ind, lambda_ind) = curr_result(7);
      
            % param = [k_set(k_ind), lambda_set(lambda_ind)];
            % for p_ind = 1:length(param) 
            %     fprintf(fileID, " param_" + num2str(p_ind)+": " + num2str(param(p_ind)));
            % end
            % fprintf(fileID, " acc: %4.2f, nmi: %4.2f, ari: %4.2f, Fscore: %4.2f\n", acc*100, nmi*100, ari*100, Fscore*100);  
        end
    end
    if ~exist("results","dir")
        mkdir("results")
    end
    cd("results")
    result_name = datasets(d_ind);
    save(result_name, "acc1" , "nmi1", "ari1", "fscore1", "purity1", ...
    "precision1", "recall1");
    cd ..
    clear acc1 nmi1 ari1 fscore1 purity1 precision1 recall1
end


function normX = normalize(X)  % GMC has its now normalization
    n = size(X{1},1) ;
    for i=1:length(X)
        tX = X{i};
        for j=1:n
            tX(j,:) = tX(j,:)/(norm(tX(j,:),2)+eps);
        end
        normX{i} = tX;
    end
end