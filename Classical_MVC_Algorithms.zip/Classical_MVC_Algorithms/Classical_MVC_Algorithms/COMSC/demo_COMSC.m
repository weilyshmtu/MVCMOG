clear
clc
close all
warning off


datasets = ["3sources","COIL20","MNIST-10k","NUS-WIDE"]
datapath = 'C:\Users\admin\OneDrive\科研\程序\DataSets\Multi-view datasets';
addpath(datapath)
addpath(genpath('.\COMSC'))

rng('default')
for d_ind=1:length(datasets)
    % filename = "COMSC_new_" + datasets(d_ind)+ ".txt";
    % fileID = fopen(filename, 'wt');
   
    load(datasets(d_ind))
    
    X = normalize(X);
    if ~exist("Y","var")
        Y = y;
    end
    n_clusters = length(unique(Y));
    n_views = size(X, 2);
    for i=1:n_views
        X{i}= X{i}';
    end
    smp_num = size(X{1}, 2);
    
    % compute kernels
    ker_num = n_views*5;
    K = zeros(smp_num, smp_num, ker_num);
    for v=1:n_views
        options.KernelType = 'Gaussian';
        K(:,:,1+(v-1)*5) = construct_kernel(X{v}', [], options);
        options.KernelType = 'Polynomial';
        options.d = 3;
        K(:,:,2+(v-1)*5) = construct_kernel(X{v}', [], options);
        options.KernelType = 'Linear';
        K(:,:,3+(v-1)*5) = construct_kernel(X{v}', [], options);
        options.KernelType = 'Sigmoid';
        options.c = 0;
        options.d = 0.1;
        K(:,:,4+(v-1)*5) = construct_kernel(X{v}', [], options);
        options.KernelType = 'InvPloyPlus';
        options.c = 0.01;
        options.d = 1;
        K(:,:,5+(v-1)*5) = construct_kernel(X{v}', [], options);
    end
    
    % center and normalized kernels
    K = kcenter(K);
    K = knorm(K);
    
    % parameters
    cset = [1:1:20]*n_clusters;
    len_cset = length(cset);
    lambda_1_set = 2.^[-10:2:10];
    len_lbd1 = length(lambda_1_set);
    lambda_2_set = 2^0; % always set to 1, for it is not discussed in the paper
    len_lbd2 = length(lambda_2_set);
    max_iter = 20;
    
    metrics_meaning = {'acc'; 'nmi'; 'purity'; 'AR'; 'RI'; 'MI'; 'HI'; 'fscore'; 'precision'; 'recall'};
    
    for ic=1:length(cset)

        if cset(ic)>=smp_num
          break;
        end

        for il=1:len_lbd1
            for ij= 1:len_lbd2
                % main algorithm
                param1 = cset(ic);
                param2 = lambda_1_set(il);
                param3 = lambda_2_set(ij);
              
                [Z, ~, ~, ~, ~ ] = CoMSC(K, param1, param2, param3, max_iter);
                PI = Z > 0;
                Z = Z.*PI;
                [U] = baseline_spectral_onkernel( abs( (Z + Z') / 2) , n_clusters);
                [y] = my_kmeans(U, n_clusters);
                [curr_result] = my_eval_y(y, Y);

                acc1(ic,il,ij) = curr_result(1)
                nmi1(ic,il,ij) = curr_result(2)
                ari1(ic,il,ij) = curr_result(4);
                fscore1(ic,il,ij) = curr_result(8)
                purity1(ic,il,ij) = curr_result(3);
                precision1(ic,il,ij) = curr_result(9);
                recall1(ic,il,ij) = curr_result(10);


                % param = [cset(ic), lambda_1_set(il), lambda_2_set(ij)];
                % for p_ind = 1:length(param) 
                %     fprintf(fileID, " param_" + num2str(p_ind)+": " + num2str(param(p_ind)));
                % end
                % fprintf(fileID, " acc: %4.2f, nmi: %4.2f, ari: %4.2f, Fscore: %4.2f\n", result(1)*100, result(2)*100, result(3)*100, result(4)*100);  
            end
        end
    end
    if ~exist("results","dir")
        mkdir("results")
    end
    cd("results")
    result_name = datasets(d_ind);
    save(result_name, "acc1" , "nmi1", "ari1", "fscore1", "purity1", ...
    "precision1", "recall1");
    cd ..
    clear acc1 nmi1 ari1 fscore1 purity1 precision1 recall1



end


function normX = normalize(X)
    n = size(X{1},1) ;
    for i=1:length(X)
        tX = X{i};
        for j=1:n
            tX(j,:) = tX(j,:)/(norm(tX(j,:),2)+eps);
        end
        normX{i} = tX;
    end
end