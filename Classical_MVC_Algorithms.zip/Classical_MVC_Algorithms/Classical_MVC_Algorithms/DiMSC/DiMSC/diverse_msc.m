
function [result CKSym] = diverse_msc(X,gt,lambda_s,lambda_v)
%data preparation
view_num = length(X);
for i =1:view_num
    D{i} = X{i};
end

N = size(D{1},2);
clusNum = size(unique(gt),1);

%representation
Z = diverse_rep(D, view_num, lambda_s, lambda_v);
%spectral Clustering
CKSym = zeros(N,N);
for v=1:view_num
    CKSym =CKSym + abs(Z{v})+abs(Z{v}');
end

C = SpectralClustering(CKSym,clusNum);
result = Clustering8Measure(gt, C);


