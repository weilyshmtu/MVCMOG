clear;
clc;
close all;

datasets = ["COIL20","MNIST-10k","NUS-WIDE"]
datapath = 'C:\Users\admin\OneDrive\科研\程序\DataSets\Multi-view datasets';
addpath(datapath)
addpath('.\SLMVGC')

alpha = [10,50,100,150];
beta = [0.001,0.005,0.01,0.1,1];
lambda = [0.1,0.5,1,5];
gamma = [0.01,0.05,0.1,1,10,50];

rag("default")
for d_ind=1:length(datasets)
    % filename = "SLMVGC_" + datasets(d_ind)+ ".txt";
    % fileID = fopen(filename, 'wt');

    load(datasets(d_ind));
    
    X = normalize(X); % to let each data sample has unit l_2 norm
    if ~exist("Y","var")
        Y = y;
    end

    % marginal notes from original demo: 
    % For HW2, the preferable parameter setting is: alpha=50  beta = 0.005
    % lambda = 0.5  gamma = 0.05
    % For ORL_mtv, the preferable parameter setting is: alpha = 100  beta =
    % 0.01  lambda = 1  gamma = 10
    
    for alpha_ind=1:length(alpha)
        for beta_ind = 1:length(beta)
            for lambda_ind = 1:length(lambda)
                for gamma_ind = 1:length(gamma)
                    [curr_result,~] = SLMVGC(X, Y, alpha(alpha_ind), beta(beta_ind), lambda(lambda_ind), gamma(gamma_ind));   %acc, nmi, Pu, Fscore, Precision, Recall, ARI
                    acc1(alpha_ind,beta_ind,lambda_ind,gamma_ind) = curr_result(1)
                    nmi1(alpha_ind,beta_ind,lambda_ind,gamma_ind) = curr_result(2)
                    ari1(alpha_ind,beta_ind,lambda_ind,gamma_ind) = curr_result(3);
                    fscore1(alpha_ind,beta_ind,lambda_ind,gamma_ind) = curr_result(4)
                    purity1(alpha_ind,beta_ind,lambda_ind,gamma_ind) = curr_result(5);
                    precision1(alpha_ind,beta_ind,lambda_ind,gamma_ind) = curr_result(6);
                    recall1(alpha_ind,beta_ind,lambda_ind,gamma_ind) = curr_result(7);
                    
                    % param = [alpha_ind(alpha_ind), beta_ind(beta_ind), lambda_ind(lambda_ind), gamma_ind(gamma_ind)];
                    % for p_ind = 1:length(param) acc
                    %     fprintf(fileID, " param_" + num2str(p_ind)+": " + num2str(param(p_ind)));
                    % end
                    % fprintf(fileID, " acc: %4.2f, nmi: %4.2f, ari: %4.2f, Fscore: %4.2f\n", result(1)*100, result(2)*100, result(3)*100, result(4)*100);  
  
                end
            end
        end
    end   
    cd("results")
    result_name = datasets(d_ind);
    save(result_name, "acc1" , "nmi1", "ari1", "fscore1", "purity1", ...
    "precision1", "recall1");
    cd ..
    clear acc1 nmi1 ari1 fscore1 purity1 precision1 recall1

end



function normX = normalize(X)    % SLMVGC has its normalization
    n = size(X{1},1) ;
    for i=1:length(X)
        tX = X{i};
        for j=1:n
            tX(j,:) = tX(j,:)/(norm(tX(j,:),2)+eps);
        end
        normX{i} = tX;
    end
end